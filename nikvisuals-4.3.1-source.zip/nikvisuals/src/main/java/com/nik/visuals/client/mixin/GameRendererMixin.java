package com.nik.visuals.client.mixin;

import com.nik.visuals.client.config.ModConfig;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void nik$noHurt(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (ModConfig.clearEffects) ci.cancel();
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true, require = 0)
    private void nik$noBob(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (ModConfig.clearEffects) ci.cancel();
    }
}
