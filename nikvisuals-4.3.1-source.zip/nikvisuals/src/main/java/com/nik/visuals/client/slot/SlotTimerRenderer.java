package com.nik.visuals.client.slot;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class SlotTimerRenderer {
    public void render(DrawContext g, float partialTick) {
        renderAfterHotbar(g, partialTick);
    }

    public static void renderAfterHotbar(DrawContext g, float partialTick) {
        if (!ModConfig.slotTimer) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.options.hudHidden) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int baseX = sw / 2 - 90;
        int slotY = sh - 19;
        float scale = Math.max(0.6f, Math.min(1.2f, ModConfig.slotTimerScale));

        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            int seconds = CooldownQuery.remainingSeconds(player, stack, partialTick);
            if (seconds < 1) continue;

            int slotX = baseX + i * 20;
            String text = String.valueOf(seconds);
            int color = seconds <= 2 ? 0xFFFF5555 : 0xFFFFFFFF;

            g.getMatrices().pushMatrix();
            float f = slotX + 10 - mc.textRenderer.getWidth(text) * scale / 2f;
            g.getMatrices().translate(f, slotY + 17 - (int) (9.0f * scale));
            g.getMatrices().scale(scale, scale);
            g.drawText(mc.textRenderer, text, 0, 0, color, true);
            g.getMatrices().popMatrix();
        }
    }
}
