package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class HungerHudRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.saturationHud) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden || mc.currentScreen != null) {
            return;
        }
        if (mc.interactionManager == null || !mc.interactionManager.hasStatusBars()) {
            return;
        }
        float saturation = p.getHungerManager().getSaturationLevel();
        if (saturation <= 0.05f) {
            return;
        }
        int left = mc.getWindow().getScaledWidth() / 2 + 91;
        int top = mc.getWindow().getScaledHeight() - 39;
        int satIcons = MathHelper.ceil((float)(saturation / 2.0f));
        for (int i = 0; i < 10; ++i) {
            if (i >= satIcons) continue;
            int x = left - i * 8 - 9;
            int y = top;
            float part = saturation - (float)i * 2.0f;
            boolean full = part >= 1.5f;
            int outer = full ? -570439606 : -1426077622;
            g.fill(x + 1, y - 2, x + 8, y - 1, outer);
            g.fill(x + 2, y - 3, x + 7, y - 2, -8054);
            if (!full) continue;
            g.fill(x + 3, y - 1, x + 6, y, -1);
        }
    }
}

