package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

@Environment(EnvType.CLIENT)
public class BlockOutlineRenderer {
    public void render(MatrixStack poseStack, VertexConsumerProvider buffers, float partialTick) {
        if (!ModConfig.blockOutline) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK
                    || buffers == null || poseStack == null) return;

            BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            float e = 0.002f;
            float x1 = (float) (pos.getX() - cam.x) - e;
            float y1 = (float) (pos.getY() - cam.y) - e;
            float z1 = (float) (pos.getZ() - cam.z) - e;
            float x2 = x1 + 1.0f + 2.0f * e;
            float y2 = y1 + 1.0f + 2.0f * e;
            float z2 = z1 + 1.0f + 2.0f * e;

            float t = (float) (System.currentTimeMillis() % 3000L) / 3000.0f;
            float pulse = (float) (0.85 + 0.15 * Math.sin(System.currentTimeMillis() / 180.0 * ModConfig.pulseSpeed));
            int rgb = Color.HSBtoRGB(t, 0.85f, 1.0f);
            int r = rgb >> 16 & 0xFF;
            int g = rgb >> 8 & 0xFF;
            int b = rgb & 0xFF;
            int a = (int) (255.0f * pulse * ModConfig.pulseIntensity);

            poseStack.push();
            Matrix4f m = poseStack.peek().getPositionMatrix();
            VertexConsumer lines = buffers.getBuffer(RenderLayers.lines());
            // bottom
            line(lines, m, x1, y1, z1, x2, y1, z1, r, g, b, a);
            line(lines, m, x2, y1, z1, x2, y1, z2, r, g, b, a);
            line(lines, m, x2, y1, z2, x1, y1, z2, r, g, b, a);
            line(lines, m, x1, y1, z2, x1, y1, z1, r, g, b, a);
            // top
            line(lines, m, x1, y2, z1, x2, y2, z1, r, g, b, a);
            line(lines, m, x2, y2, z1, x2, y2, z2, r, g, b, a);
            line(lines, m, x2, y2, z2, x1, y2, z2, r, g, b, a);
            line(lines, m, x1, y2, z2, x1, y2, z1, r, g, b, a);
            // pillars
            line(lines, m, x1, y1, z1, x1, y2, z1, r, g, b, a);
            line(lines, m, x2, y1, z1, x2, y2, z1, r, g, b, a);
            line(lines, m, x2, y1, z2, x2, y2, z2, r, g, b, a);
            line(lines, m, x1, y1, z2, x1, y2, z2, r, g, b, a);
            poseStack.pop();
        } catch (Throwable ignored) {
            // never crash the client for outline
        }
    }

    /** 1.21.11 lines format requires LineWidth on each vertex */
    private static void line(VertexConsumer buf, Matrix4f m,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             int r, int g, int b, int a) {
        float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        float w = 2.0f;
        buf.vertex(m, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz).lineWidth(w);
        buf.vertex(m, x2, y2, z2).color(r, g, b, a).normal(nx, ny, nz).lineWidth(w);
    }
}
