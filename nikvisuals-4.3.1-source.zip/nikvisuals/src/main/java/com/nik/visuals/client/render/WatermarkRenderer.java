package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

@Environment(EnvType.CLIENT)
public class WatermarkRenderer {
    public static final int BOX_W = 168;
    public static final int BOX_H = 18;

    private int lastX, lastY, lastW = BOX_W, lastH = BOX_H;
    private int fpsSmooth;
    private float appear;
    private float alertPulse;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    public void render(DrawContext g, float pt) {
        boolean want = ModConfig.watermark || ModConfig.layoutEdit;
        appear = Anim.approach(appear, want ? 1f : 0f, 0.14f);
        if (appear < 0.02f) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float a = Anim.easeOutCubic(appear);
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int x = Math.max(2, Math.min(sw - BOX_W - 2, (int) (ModConfig.watermarkX * sw) - BOX_W / 2));
        int y = Math.max(2, Math.min(sh - BOX_H - 2, (int) (ModConfig.watermarkY * sh)));
        lastX = x;
        lastY = y;
        lastW = BOX_W;
        lastH = BOX_H;

        int fps = mc.getCurrentFps();
        fpsSmooth = fpsSmooth == 0 ? fps : (fpsSmooth * 4 + fps) / 5;
        int ping = 0;
        try {
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry info = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (info != null) ping = info.getLatency();
            }
        } catch (Throwable ignored) {}

        boolean alert = fpsSmooth < 40 || ping > 150;
        alertPulse = Anim.approach(alertPulse, alert ? 1f : 0f, 0.1f);

        GuiDraw.glassPanel(g, x, y, BOX_W, BOX_H, 8,
                Style.alpha(Style.PANEL, a),
                Style.alpha(alert ? Style.WARN : Style.ACCENT_GLOW, a * (0.5f + 0.5f * alertPulse)));
        g.fill(x, y + 3, x + 2, y + BOX_H - 3, Style.alpha(Style.ACCENT, a));

        g.drawText(mc.textRenderer, "Nik Visuals", x + 10, y + 5, Style.alpha(Style.TEXT, a), false);

        int fpsC = fpsSmooth >= 100 ? Style.OK : (fpsSmooth >= 50 ? Style.TEXT_DIM : Style.DANGER);
        int pingC = ping <= 60 ? Style.OK : (ping <= 120 ? Style.WARN : Style.DANGER);
        if (alert) {
            float pulse = 0.7f + 0.3f * (float) Math.sin(System.currentTimeMillis() / 180.0);
            fpsC = Style.alpha(fpsC, a * pulse);
            pingC = Style.alpha(pingC, a * pulse);
        } else {
            fpsC = Style.alpha(fpsC, a);
            pingC = Style.alpha(pingC, a);
        }

        String pingStr = ping + " ms";
        String fpsStr = fpsSmooth + " FPS";
        int right = x + BOX_W - 8;
        g.drawText(mc.textRenderer, pingStr, right - mc.textRenderer.getWidth(pingStr), y + 5, pingC, false);
        right -= mc.textRenderer.getWidth(pingStr) + 8;
        g.drawText(mc.textRenderer, fpsStr, right - mc.textRenderer.getWidth(fpsStr), y + 5, fpsC, false);
    }
}
