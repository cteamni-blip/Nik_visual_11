package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

@Environment(EnvType.CLIENT)
public class WeatherHandler {
    public void tick(MinecraftClient mc) {
        if (ModConfig.weatherMode == 0) {
            return;
        }
        ClientWorld level = mc.world;
        if (level == null) {
            return;
        }
        try {
            switch (ModConfig.weatherMode) {
                case 1: {
                    level.setRainGradient(0.0f);
                    level.setThunderGradient(0.0f);
                    break;
                }
                case 2: {
                    level.setRainGradient(1.0f);
                    level.setThunderGradient(0.0f);
                    break;
                }
                case 3: {
                    level.setRainGradient(1.0f);
                    level.setThunderGradient(1.0f);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

