package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.slot.CooldownQuery;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class CooldownHudRenderer {
    private float appear;
    private int lastX, lastY, lastW, lastH;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    private static class Row {
        final ItemStack stack;
        final String name;
        final int seconds;
        Row(ItemStack s, String n, int sec) { stack = s; name = n; seconds = sec; }
    }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.cooldownHud && !ModConfig.layoutEdit) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;

        Map<String, Row> map = new LinkedHashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            int sec = CooldownQuery.remainingSeconds(p, st, pt);
            if (sec < 1) continue;
            String name = st.getName().getString().replaceAll("§.", "");
            if (name.length() > 18) name = name.substring(0, 17) + "…";
            Row prev = map.get(name);
            if (prev == null || sec > prev.seconds) {
                map.put(name, new Row(st.copy(), name, sec));
            }
        }

        List<Row> rows = new ArrayList<>(map.values());
        boolean show = !rows.isEmpty() || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.15f);
        if (appear < 0.02f) return;

        float a = Anim.easeOutCubic(appear);
        float scale = Math.max(0.6f, Math.min(1.8f, ModConfig.cooldownHudScale));
        int x = (int) (ModConfig.cooldownHudX * mc.getWindow().getScaledWidth());
        int y = (int) (ModConfig.cooldownHudY * mc.getWindow().getScaledHeight());

        if (rows.isEmpty() && ModConfig.layoutEdit) {
            lastX = x; lastY = y; lastW = (int) (120 * scale); lastH = (int) (28 * scale);
            g.getMatrices().pushMatrix();
            g.getMatrices().translate(x, y);
            g.getMatrices().scale(scale, scale);
            GuiDraw.glassPanel(g, 0, 0, 120, 28, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
            g.drawText(mc.textRenderer, "Кулдауны", 12, 10, Style.alpha(Style.TEXT_DIM, a), false);
            g.getMatrices().popMatrix();
            return;
        }
        if (rows.isEmpty()) return;

        int lineH = 18;
        int w = 130;
        for (Row r : rows) {
            w = Math.max(w, 28 + mc.textRenderer.getWidth(r.name) + 36);
        }
        int h = 8 + rows.size() * lineH;
        lastX = x; lastY = y;
        lastW = (int) (w * scale);
        lastH = (int) (h * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x + (1f - a) * -8, y);
        g.getMatrices().scale(scale, scale);
        GuiDraw.glassPanel(g, 0, 0, w, h, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));

        int row = 0;
        for (Row r : rows) {
            int ry = 5 + row * lineH;
            GuiDraw.fillRounded(g, 4, ry, 14, 14, 4, Style.alpha(Style.GLASS, a));
            g.drawItem(r.stack, 5, ry);
            g.drawText(mc.textRenderer, r.name, 22, ry + 3, Style.alpha(Style.TEXT, a), false);
            String ts = r.seconds + "с";
            int tw = mc.textRenderer.getWidth(ts);
            g.drawText(mc.textRenderer, ts, w - 8 - tw, ry + 3, Style.alpha(Style.ACCENT, a), false);
            row++;
        }
        g.getMatrices().popMatrix();
    }
}
