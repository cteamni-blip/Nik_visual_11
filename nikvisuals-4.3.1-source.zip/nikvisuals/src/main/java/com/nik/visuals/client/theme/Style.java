package com.nik.visuals.client.theme;

/** Black / gray / green — polished */
public final class Style {
    private Style() {}

    public static final int BG_DEEP      = 0xF0050505;
    public static final int PANEL       = 0xF0101010;
    public static final int PANEL2      = 0xF0141414;
    public static final int GLASS       = 0xD00C0C0C;
    public static final int ACCENT      = 0xFF3DCC7A;
    public static final int ACCENT_DIM  = 0x9933AA66;
    public static final int ACCENT_GLOW = 0x5533CC77;
    public static final int TEXT        = 0xFFF0F0F0;
    public static final int TEXT_DIM    = 0xFF8A8A8A;
    public static final int DANGER      = 0xFFFF5555;
    public static final int WARN        = 0xFFDDBB44;
    public static final int OK          = 0xFF55CC88;
    public static final int ROW_HOV     = 0x3322AA55;
    public static final int DIVIDER     = 0x3322AA55;
    public static final int TRACK_OFF   = 0xFF2A2A2A;
    public static final int KNOB        = 0xFFF5F5F5;

    public static int alpha(int argb, float a) {
        int aa = Math.max(0, Math.min(255, (int) (((argb >>> 24) & 0xFF) * a)));
        return (aa << 24) | (argb & 0x00FFFFFF);
    }

    public static int solidAlpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0x00FFFFFF);
    }

    public static void applyHudTheme(int id) {
        switch (id) {
            case 1 -> { // glass
                PANEL = 0xCC0E1412;
                ACCENT = 0xFF5DFFB0;
                ACCENT_GLOW = 0x665DFFB0;
                TEXT = 0xFFE8F5EC;
            }
            case 2 -> { // combat red-gray
                PANEL = 0xCC121010;
                ACCENT = 0xFFFF5555;
                ACCENT_GLOW = 0x66FF5555;
                TEXT = 0xFFFFF0F0;
            }
            default -> { // minimal black-green
                PANEL = 0xE0101010;
                ACCENT = 0xFF3DCC7A;
                ACCENT_GLOW = 0x443DCC7A;
                TEXT = 0xFFE8E8E8;
            }
        }
    }
}
